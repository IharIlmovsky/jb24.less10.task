package by.epam.library.view;

import java.util.*;

import by.epam.library.entity.PrintedEdition;

public interface Printable {
	void print(List<PrintedEdition> items);
}
